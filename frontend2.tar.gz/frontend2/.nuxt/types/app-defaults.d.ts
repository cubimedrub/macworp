
declare module '#app/defaults' {
  type DefaultAsyncDataErrorValue = null
  type DefaultAsyncDataValue = null
  type DefaultErrorValue = null
  type DedupeOption = boolean | 'cancel' | 'defer'
}