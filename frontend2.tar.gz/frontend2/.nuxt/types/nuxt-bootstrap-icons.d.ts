declare global {
  type BootstrapIcons =
    keyof typeof import("bootstrap-icons/font/bootstrap-icons.json");
}

export {};
