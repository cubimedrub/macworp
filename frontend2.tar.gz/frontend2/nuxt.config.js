// https://nuxt.com/docs/api/configuration/nuxt-config
export default defineNuxtConfig({
  compatibilityDate: '2024-11-01',
  devtools: { enabled: true },
  css: ['~/assets/sass/application.sass'],
  modules: ['@pinia/nuxt', 'nuxt-bootstrap-icons'],
  sass: {
    sassOptions: {
      quietDeps: true,
      silenceDeprecations: ['legacy-js-api', 'mixed-decls', 'color-functions', 'global-builtin', 'import']
    }
  }
})