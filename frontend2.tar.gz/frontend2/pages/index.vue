<template>
    <div class="dashboard">
        <h1>Welcome to MAcWorP</h1>
    </div>
</template>

<script>
    export default {
    }
</script>

<style>
</style>
