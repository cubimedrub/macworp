import { useAppStore } from '~/store'

export default defineNuxtPlugin(({ $pinia }) => {
    return {
        provide: {
            store: useAppStore($pinia)
        }
    }
})