import { defineStore } from 'pinia'

export const useAppStore = defineStore('app', {
    state: () => ({
        is_menu_open: false,
    }),
    actions: {
        close_menu() {
            this.is_menu_open = false
        },
        open_menu() {
            this.is_menu_open = true
        },
    },
})